#!/bin/bash

export private_endpoint_name="private_endpoint_name"
export resource_group_name="resource_group_name"
export subnet_name="subnet_name"
export vnet_name="vnet_name"
export vnet_resource_group="vnet_resource_group"
export resource_name="resource_name"
export private_dns_zone="private_dns_zone"
export subresource_name="subresource_name"
export use_existing_private_endpoint="use_existing_private_endpoint"
export subscriptionID="subscriptionID"

# Function to retrieve value from tfvars file
get_tfvar_value() {
    block_name=$1
    var_name=$2
    awk -v block="$block_name" -v var="$var_name" '
    BEGIN { RS="\n\n"; FS="\n"; }
    $0 ~ block { for (i=1; i<=NF; i++) if ($i ~ var) { split($i, a, "="); print a[2]; exit } }
    ' ./sample.tfvars | sed 's/^[ \t]*//;s/[ \t]*$//'
}

# Retrieve the use_existing_private_endpoint value
use_existing_private_endpoint=$(get_tfvar_value "use_existing_private_endpoint" "use_existing_private_endpoint")
echo "use_existing_private_endpoint value is: $use_existing_private_endpoint"

if [ "$use_existing_private_endpoint" == "true" ]; then
    echo "Fetching 'existing_private_endpoint' details as 'use_existing_private_endpoint' is TRUE"

    # Retrieve values for existing private endpoint
    private_endpoint_name=$(get_tfvar_value "existing_private_endpoint" "private_endpoint_name")
    resource_group_name=$(get_tfvar_value "existing_private_endpoint" "resource_group_name")
    private_dns_zone=$(get_tfvar_value "existing_private_endpoint" "private_dns_zone")
    subresource_name=$(get_tfvar_value "existing_private_endpoint" "subresource_name")
    subscriptionID=$(get_tfvar_value "existing_private_endpoint" "subscriptionID")

    echo "private_endpoint_name value is: $private_endpoint_name"
    echo "resource_group_name value is: $resource_group_name"
    echo "private_dns_zone value is: $private_dns_zone"
    echo "subresource_name value is: $subresource_name"
    echo "subscriptionID value is: $subscriptionID"

else
    echo "Fetching 'new_private_endpoint' details as 'use_existing_private_endpoint' is FALSE"

    # Retrieve values for new private endpoint
    private_endpoint_name=$(get_tfvar_value "new_private_endpoint" "private_endpoint_name")
    resource_group_name=$(get_tfvar_value "new_private_endpoint" "resource_group_name")
    subnet_name=$(get_tfvar_value "new_private_endpoint" "subnet_name")
    vnet_name=$(get_tfvar_value "new_private_endpoint" "vnet_name")
    vnet_resource_group=$(get_tfvar_value "new_private_endpoint" "vnet_resource_group")
    resource_name=$(get_tfvar_value "new_private_endpoint" "resource_name")
    private_dns_zone=$(get_tfvar_value "new_private_endpoint" "private_dns_zone")
    subresource_name=$(get_tfvar_value "new_private_endpoint" "subresource_name")
    subscriptionID=$(get_tfvar_value "existing_private_endpoint" "subscriptionID")

    echo "private_endpoint_name value is: $private_endpoint_name"
    echo "resource_group_name value is: $resource_group_name"
    echo "subnet_name value is: $subnet_name"
    echo "vnet_name value is: $vnet_name"
    echo "vnet_resource_group value is: $vnet_resource_group"
    echo "resource_name value is: $resource_name"
    echo "private_dns_zone value is: $private_dns_zone"
    echo "subresource_name value is: $subresource_name"
    echo "subscriptionID value is: $subscriptionID"
fi
